package com.fis.cussaccapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

//import com.fis.custservice.model.Customer;
//import com.fis.custservice.service.CustomerService;
//import com.fis.custservice.dao.CustomerDao;
 
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.fis.cusaccapp.dao.CustomerDao;
import com.fis.cusaccapp.models.Customer;
import com.fis.cusaccapp.services.CustomerService;
 
//import com.fis.custservice.exception.NoRecordsException;


//@ContextConfiguration
@SpringBootTest
class BankingAppApplicationTests {
	@MockBean
	CustomerDao dao;
	@Autowired
	CustomerService service;
 
 
	
	@Test
	public void testcreateCustomer() {
		Customer customer = new Customer(123,"sandeep",8830309095l,"Akshay@123", "san@gmail.com", "27-04-2001","fcgvhb");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		boolean res = service.createCustomer(customer);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
	@DisplayName("View Customer- Successful")
	public void testshowCustomerData() {
		Customer customer = new Customer(123,"sandeep",8830309095l,"Akshay@123", "san@gmail.com", "27-04-2001","fcgvhb");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		List<Customer> custList=new ArrayList<Customer>();
		List<Customer> recustList= new ArrayList<Customer>();
       
        Mockito.when(dao.findAll()).thenReturn(custList);
       	recustList = service.showCustomerData();
       	assertEquals(custList, recustList);
}
//	
//	@Autowired
//	CustomerService service;
//	@Autowired
//	AccountService service1;
//	@Autowired
//	TransactionService service2;
////
////	@Test
////	void contextLoads() {
////	}
//	@Test
//		public void testcreateCustomer() {
//			Customer customer = new Customer(123,"sandeep",8830309095l,"Akshay@123", "san@gmail.com", "27-04-2001","fcgvhb");
//			String msg = service.createCustomer(customer);
//			assertEquals("Customer Created Successfully",msg);
//		}
//	
//	@Test
//	   public void testcreateAccount() {
//			Customer customer = new Customer(12,"sandeep",8830309095l,"Akshay@123", "san@gmail.com", "27-04-2001","fcgvhb");
//			Account account = new Account( 111, customer, "Savings" ,LocalDate.now(), 1234, "Aundh");
//			String msg = service1.createAccount(account);
//			assertEquals("Account Created Successfully",msg);
//	}
//	
//	@Test
//		public void testupdateAccount() {
//		Customer customer = new Customer(12,"sandeep",8830309095l,"Akshay@123", "san@gmail.com", "27-04-2001","fcgvhb");
//		Account account = new Account( 111, customer, "Savings" ,LocalDate.now(), 1234, "kukatpally");
//		String msg = service1.updateAccount(account);
//		assertEquals("Account Updated Successfully",msg); 	
//	}
//	
//	@Test
//		public void testdeleteAccount() throws AccountNotFound {
//		String msg = service1.deleteAccount(27);
//		assertEquals("Account Deleted Successfully",msg);
//	}
//	
//	@Test
//		public void testdeposit() throws AccountNotFound {
//		String msg = service1.deposit(19, 1000);
//		assertEquals("Amount Deposited Successfully",msg);
//	}
//	
//	@Test
//		public void testwithdraw() throws AccountNotFound, NotEnoughBalance {
//		String msg = service1.withdraw(19, 500);
//		assertEquals("Amount Withdrawed Successfully",msg);
//	}
//	
//	@Test
//		public void testfundTransfer() throws AccountNotFound, NotEnoughBalance {
//		String msg = service1.fundTransfer(19, 8, 0);
//		assertEquals("Fund Transfer Successfully",msg);
//	}
}

