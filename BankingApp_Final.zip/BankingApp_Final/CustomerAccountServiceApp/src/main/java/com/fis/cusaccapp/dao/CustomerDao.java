package com.fis.cusaccapp.dao;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.cusaccapp.models.Customer;


public interface CustomerDao extends JpaRepository<Customer,Integer>{
	// This is the interface in dao layer for customer transactions
//	public String createCustomer(Customer customer );
//	public List<Customer> showCustomerData();
	
	public Customer findByCustomerName(String customerName);
}
