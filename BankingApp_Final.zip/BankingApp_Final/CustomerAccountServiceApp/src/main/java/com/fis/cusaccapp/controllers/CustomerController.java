package com.fis.cusaccapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.cusaccapp.models.Customer;
import com.fis.cusaccapp.models.CustomerDTO;
import com.fis.cusaccapp.services.CustomerService;


//{
//	"customerName": ""Akshay",
//	"customermobno": 8830309095,
//	"password": "Akshay@123",
//	"customermail": "a@gmail.com",
//	"customerdob": "27/04/2001",
//	"customerpermadd": "pune"
//}
@RestController
//@RequestMapping("/customer") // http://localhost:8080/customer
public class CustomerController {
	@Autowired
	CustomerService service;
	
	@PostMapping("/createCustomer") // http://localhost:8080/customer/createCustomer
	public ResponseEntity<Object> createCustomer(@RequestBody @Validated Customer customer ) {
		if(service.createCustomer(customer)){
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
		}
	
	
	@GetMapping("/showCustomerData") // http://localhost:8080/customer/showCustomerData
	public ResponseEntity<CustomerDTO> showCustomerData(){
		CustomerDTO dto=new CustomerDTO();
		dto.setList(service.showCustomerData());
		return new ResponseEntity<CustomerDTO>(dto,HttpStatus.OK);
		
	}
	
	@PostMapping("/customerLogin")
	public ResponseEntity<Customer> customerLogin(@RequestBody Customer user){
		Customer u =service.isValid(user.getCustomerName(),user.getPassword());
		
		return new ResponseEntity<Customer>(u,HttpStatus.OK);
	}

}
