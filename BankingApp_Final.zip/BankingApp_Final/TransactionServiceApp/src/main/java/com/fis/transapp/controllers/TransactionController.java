package com.fis.transapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.fis.transapp.models.Transaction;
import com.fis.transapp.models.TransactionDTO;
import com.fis.transapp.services.TransactionService;

@RestController
public class TransactionController {

	@Autowired
	private TransactionService service;
		
		@GetMapping("/showTransactionData")
		public ResponseEntity<TransactionDTO> showTransactionData(){
			TransactionDTO dto=new TransactionDTO();
			
			dto.setList(service.showTransactionData());
			System.out.println("checkin transaction in transaction controller"+dto);
			return new ResponseEntity<TransactionDTO>(dto,HttpStatus.OK);
		}
		
		@PostMapping("/addTransaction")
		public ResponseEntity<Object> addTransaction(@RequestBody Transaction transaction){
			if(service.addTransaction(transaction)) {
				return new ResponseEntity<Object>(HttpStatus.CREATED);
			}
			else
				return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
		}
		
		@GetMapping("/getTransactionByAcc")
		public ResponseEntity<TransactionDTO> getTransactionByAcc(@RequestBody long accNo ){
			TransactionDTO dto=new TransactionDTO();
			dto.setList(service.getTransactionByAcc(accNo));
			return new ResponseEntity<TransactionDTO>(dto,HttpStatus.OK);
		}
		
}
